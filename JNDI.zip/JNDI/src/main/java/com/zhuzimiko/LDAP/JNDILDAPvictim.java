package com.zhuzimiko.LDAP;

import com.zhuzimiko.RemoteObj;

import javax.naming.InitialContext;

public class JNDILDAPvictim {

    public static void main(String[] args) throws Exception{
        InitialContext initialContext = new InitialContext();
        RemoteObj remoteObj = (RemoteObj) initialContext.lookup("ldap://localhost:1234/remoteObj");
        System.out.println(remoteObj.sayHello("hello"));
    }

}
